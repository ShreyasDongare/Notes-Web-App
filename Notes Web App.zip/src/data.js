export const data = [
  {
    id: 1,
    title: "Lorem =sit amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehen.",
    date: "2-jan-2023",
  },
  {
    id: 2,
    title: "L=um dolor sit amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat  accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 3,
    title: "= sit amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam repr.",
    date: "2-jan-2023",
  },
  {
    id: 4,
    title: "=ipsum dolor sit amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 5,
    title: "Lorem = amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 6,
    title: "Lorem ipsum dolor =?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 7,
    title: "Lorem ipsum dolor =r?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 8,
    title: "Lorem ipsum  consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 9,
    title: "Lorem ipsum dolor  consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
  {
    id: 10,
    title: "Lorem  dolor sit amet consectetur?",
    note: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Unde commodi distinctio animi totam reprehenderit earum, aliquid dolor nisi fugiat nostrum, voluptatum, vel modi? Quos, accusamus.",
    date: "2-jan-2023",
  },
];